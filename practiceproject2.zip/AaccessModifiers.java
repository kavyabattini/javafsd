/**
 * 
 */
package practiceproject2;

/**
 * 
 */
public class AaccessModifiers {

	/**
	
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

				//default access modifier
						int AaccessModifiers }
					//private access modifier
						private int num2;
					//public access modifier
						public int num3;
					//protected access modifier
						protected int num4;
						private int AaccessModifiers;
						
						//Main method
						public static void 2r {
							AaccessModifiers AaccessModifiersobj=new AaccessModifiers();
							AaccessModifiersobj.AaccessModifiers=10;
							AaccessModifiersobj.num2=20;
							AaccessModifiersobj.num3=30;
							AaccessModifiersobj.num4=40;
							System.out.println("num1:" + AaccessModifiersobj.AaccessModifiers);
							System.out.println("num2:" + AaccessModifiersobj.num2);
							System.out.println("num3:" + AaccessModifiersobj.num3);
							System.out.println("num4:" + AaccessModifiersobj.num4);
			

		
	}

}
