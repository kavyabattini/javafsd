/**
 * 
 */
package practiceproject3;

public class MethodOverloading {


		// TODO Auto-generated method stub
		public void area(int b,int h)
	    {
	         System.out.println("Area of Triangle : "+(0.5*b*h));
	    }
	    public void area(int r) 
	    {
	         System.out.println("Area of Circle : "+(3.14*r*r));
	    }

	    public static void main(String args[])
	   {

	MethodOverloading methodOverloadingobj=new MethodOverloading();
	methodOverloadingobj.area(15,18);
	methodOverloadingobj.area(8);  

	}
	
	}


