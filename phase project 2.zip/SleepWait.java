package PHASE1;

public class SleepWait {
	public static void main(String[] args) {
			// TODO Auto-generated method stub
			final Object lock=new Object();
			Thread thread1=new Thread(()->
			{
				System.out.println("Thread 1 is sleeping for 2 seconds");
				try {
					Thread.sleep(2000);
				}catch(InterruptedException e) {
					e.printStackTrace();
				}
				System.out.println("Thread 1 has woken up");
			});
			Thread thread2=new Thread(()->
			{
				synchronized(lock) {
					System.out.println("Thread 2 is waiting");
					try {
						lock.wait();
					}catch(InterruptedException e) {
						e.printStackTrace();
					}
					System.out.println("Thread 2 has been notified");
				}
			});
	        thread1.start();
	        thread2.start();
	        try {
	        	Thread.sleep(1000);
	        }catch(InterruptedException e)
	        {
	        	e.printStackTrace();
	        }
	        synchronized(lock) {
	        	lock.notify();
	        }


		}

	}

