package PHASE;
	import java.util.Arrays;

	public class ExponentialSearch {
	    public static int exponentialSearch(int[] arr, int key) {
	        if (arr[0] == key) {
	            return 0; // Element found at the first position
	        }

	        int i = 1;
	        int n = arr.length;

	        while (i < n && arr[i] <= key) {
	            i *= 2;
	        }

	        return Arrays.binarySearch(arr, i / 2, Math.min(i, n), key);
	    }

	    public static void main(String[] args) {
	        int[] arr = {2, 4, 6, 8, 10, 12, 14, 16, 18, 20};
	        int key = 12;
	        int result = exponentialSearch(arr, key);

	        if (result >= 0) {
	            System.out.println("Element " + key + " found at index " + result);
	        } else {
	        	 System.out.println("Element " + key + " not found in the array.");
	        }
	    }
	}




