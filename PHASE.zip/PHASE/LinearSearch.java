package PHASE;

public class LinearSearch {

	    public static int linearSearch(int[] arr, int target) {
	        for (int i = 0; i < arr.length; i++) {
	            if (arr[i] == target) {
	                return i; // Return the index of the target element
	            }
	        }
	        return -1; // Return -1 if the element is not found
	    }

	    public static void main(String[] args) {
	        int[] arr = {10, 25, 30, 45, 50, 65, 70};
	        int target = 45;

	        int index = linearSearch(arr, target);

	        if (index != -1) {
	            System.out.println("Element found at index " + index);
	        } else {
	            System.out.println("Element not found in the array.");
	        }
	    }
	}


