package PHASE1;
	import java.io.IOException;
	import java.io.File;
	import java.io.FileWriter;
	import java.io.FileReader;
	import java.io.BufferedWriter;
	import java.io.BufferedReader;

	public class FileCRUDOperations {

		public static void main(String[] args) {
			// TODO Auto-generated method stub
			File file=new File("c.txt");
			try {
				file.createNewFile();
				System.out.println("File created:"+file.getName());
			}catch(IOException e) {
				System.out.println("An error occurred while creating the file");
				e.printStackTrace();
			}
			try(FileWriter writer=new FileWriter(file);
					BufferedWriter bufferedWriter=new BufferedWriter(writer)){
				  
				  System.out.println("Data written to the file");
			}catch(IOException e) {
				System.out.println("An error occurred while writing to the file");
				e.printStackTrace();
			}
			try(FileReader reader=new FileReader(file);
					BufferedReader bufferedReader=new BufferedReader(reader)){
				String line;
				while((line=bufferedReader.readLine())!=null) {
					System.out.println("Data read from the file:"+line);
				}
				
			}catch(IOException e) {
				System.out.println("An error occurred while reading from the file");
				e.printStackTrace();
			}
		if(file.delete()) {
			System.out.println("File deleted:"+file.getName());
			
			}else {
				System.out.println("An error occurred while deleting the file");
			}

		}

	}

