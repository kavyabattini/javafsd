package phase1;
	import java.util.Queue;
	import java.util.LinkedList;

	public class QueueExample {
	    public static void main(String[] args) {
	        // Create a queue using LinkedList
	        Queue<String> queue = new LinkedList<>();

	        // Insert elements into the queue
	        queue.offer("First");
	        queue.offer("Second");
	        queue.offer("Third");

	        // Display the queue
	        System.out.println("Queue: " + queue);

	        // Remove and display elements from the queue
	        String removed = queue.poll();
	        System.out.println("Removed from the queue: " + removed);

	        // Display the updated queue
	        System.out.println("Updated Queue: " + queue);
	    }
	}


