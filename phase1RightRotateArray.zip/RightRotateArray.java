package phase1;

import java.util.Arrays;

public class RightRotateArray {
	
	    public static void main(String[] args) {
	        int[] originalArray = {1, 2, 3, 4, 5, 6, 7, 8, 9};
	        int rotateSteps = 5;

	        int[] rotatedArray = rightRotate(originalArray, rotateSteps);

	        System.out.println("Original Array: " + Arrays.toString(originalArray));
	        System.out.println("Rotated Array: " + Arrays.toString(rotatedArray));
	    }

	    public static int[] rightRotate(int[] arr, int steps) {
	        int length = arr.length;
	        int[] rotatedArray = new int[length];

	        for (int i = 0; i < length; i++) {
	            int newPosition = (i + steps) % length;
	            rotatedArray[newPosition] = arr[i];
	        }

	        return rotatedArray;
	    }
	}



