/**
 * 
 */

/**
 * 
 */
public class VerifyMaps {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		   public static void main(String[] args) {
				
				Map<String, Integer>
				map= new HashMap<>();
				map.put("One",1);
				map.put("Two",2);
				map.put("Three",3);
				
			//verify size of a Map
				assert map.size()==3;
				
			//verify Values of a Map
				assert map.get("One")==1;
				assert map.get("Two")==2;
				assert map.get("Three")==3;
				
			//Verify that the map contains a key
				assert map.containsKey("One");
				assert map.containsKey("Three");
				
			//Verify that the map not contains a key
				
				assert !map.containsKey("Five");
				assert !map.containsKey("six");
				
				System.out.println("All tests Passed");
				



				
			}

		}
	}

}
