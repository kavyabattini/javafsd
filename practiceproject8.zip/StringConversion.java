package practiceproject8;

public class StringConversion {
	public static void main(String[] args) {
		 String str = "Hello World!";
	        StringBuffer stringbufferobj = new StringBuffer(str);
	        StringBuilder stringBufferobj = new StringBuilder(str);

	        System.out.println("String: " + str);
	        System.out.println("StringBuffer: " + stringbufferobj);
	        System.out.println("StringBuilder: " + stringBufferobj);
	}

}

