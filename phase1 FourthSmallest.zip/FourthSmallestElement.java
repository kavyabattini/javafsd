package phase1;
	import java.util.Arrays;

	public class FourthSmallestElement {
		public static int findFourthSmallest(int[] arr) {
			if(arr.length<4) {
				return-1;
				
			}
			Arrays.sort(arr);
			return arr[3];
		}
		public static void main(String[] args) {
			int[] unsortedArray= {12,3,7,1,6,9,2,5};
			int fourthSmallest=findFourthSmallest(unsortedArray);
			if(fourthSmallest !=-1) {
				System.out.println("The fourth smallest element is:"+fourthSmallest);
			}else {
				System.out.println("There are not enough element in the array to find the fourth smallest");
			}
			
			
		}
		

	}

