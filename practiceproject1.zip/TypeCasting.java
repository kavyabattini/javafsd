/**
 * 
 */
package Camelcasting;

/**
 * 
 */
public class TypeCasting {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
int numInt=30;
double numDouble=numInt;
System.out.print("Implicity Casting(Widening):"+numDouble);
double anotherDouble=70.0;
int anotherInt=(int)anotherDouble;

System.out.print("Explicity Casting(Narrowing):"+anotherInt);
          
	}

}
